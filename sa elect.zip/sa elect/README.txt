When saving a file with based of a poll append saprojection with the date in MMDD form follewed by the name of the pollster.
Ie saprojection0112Morgan.csv 